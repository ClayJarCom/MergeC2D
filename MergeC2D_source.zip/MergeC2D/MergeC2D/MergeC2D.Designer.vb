﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MergeC2D
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MergeC2D))
        Me.OpenC2D = New System.Windows.Forms.OpenFileDialog()
        Me.SaveAs = New System.Windows.Forms.SaveFileDialog()
        Me.MergeBox = New System.Windows.Forms.GroupBox()
        Me.MergeList = New System.Windows.Forms.ListView()
        Me.LoadFile = New System.Windows.Forms.Button()
        Me.SaveFile = New System.Windows.Forms.Button()
        Me.Clear = New System.Windows.Forms.Button()
        Me.MergeBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'OpenC2D
        '
        Me.OpenC2D.DefaultExt = "c2d"
        Me.OpenC2D.Filter = "Carbide Create files|*.c2d"
        Me.OpenC2D.Title = "Open main Carbide Create file"
        '
        'SaveAs
        '
        Me.SaveAs.DefaultExt = "c2d"
        Me.SaveAs.Filter = "Carbide Create files|*.c2d"
        Me.SaveAs.Title = "Save merged Carbide Create file as..."
        '
        'MergeBox
        '
        Me.MergeBox.Controls.Add(Me.MergeList)
        Me.MergeBox.Location = New System.Drawing.Point(6, 0)
        Me.MergeBox.Name = "MergeBox"
        Me.MergeBox.Size = New System.Drawing.Size(320, 150)
        Me.MergeBox.TabIndex = 1
        Me.MergeBox.TabStop = False
        Me.MergeBox.Text = "C2D Files"
        '
        'MergeList
        '
        Me.MergeList.Location = New System.Drawing.Point(10, 19)
        Me.MergeList.Name = "MergeList"
        Me.MergeList.Size = New System.Drawing.Size(300, 125)
        Me.MergeList.TabIndex = 2
        Me.MergeList.UseCompatibleStateImageBehavior = False
        Me.MergeList.View = System.Windows.Forms.View.List
        '
        'LoadFile
        '
        Me.LoadFile.AutoSize = True
        Me.LoadFile.Location = New System.Drawing.Point(140, 156)
        Me.LoadFile.Name = "LoadFile"
        Me.LoadFile.Size = New System.Drawing.Size(72, 25)
        Me.LoadFile.TabIndex = 1
        Me.LoadFile.Text = "Load File"
        Me.LoadFile.UseVisualStyleBackColor = True
        '
        'SaveFile
        '
        Me.SaveFile.AutoSize = True
        Me.SaveFile.Enabled = False
        Me.SaveFile.Location = New System.Drawing.Point(218, 156)
        Me.SaveFile.Name = "SaveFile"
        Me.SaveFile.Size = New System.Drawing.Size(107, 25)
        Me.SaveFile.TabIndex = 2
        Me.SaveFile.Text = "Save Merged File"
        Me.SaveFile.UseVisualStyleBackColor = True
        '
        'Clear
        '
        Me.Clear.AutoSize = True
        Me.Clear.DialogResult = System.Windows.Forms.DialogResult.Abort
        Me.Clear.Location = New System.Drawing.Point(6, 156)
        Me.Clear.Name = "Clear"
        Me.Clear.Size = New System.Drawing.Size(68, 25)
        Me.Clear.TabIndex = 3
        Me.Clear.Text = "Clear"
        Me.Clear.UseVisualStyleBackColor = True
        '
        'MergeC2D
        '
        Me.AcceptButton = Me.LoadFile
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Clear
        Me.ClientSize = New System.Drawing.Size(332, 187)
        Me.Controls.Add(Me.Clear)
        Me.Controls.Add(Me.SaveFile)
        Me.Controls.Add(Me.LoadFile)
        Me.Controls.Add(Me.MergeBox)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimumSize = New System.Drawing.Size(348, 226)
        Me.Name = "MergeC2D"
        Me.Text = "MergeC2D"
        Me.MergeBox.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents OpenC2D As OpenFileDialog
    Friend WithEvents SaveAs As SaveFileDialog
    Friend WithEvents MergeBox As GroupBox
    Friend WithEvents LoadFile As Button
    Friend WithEvents SaveFile As Button
    Friend WithEvents Clear As Button
    Friend WithEvents MergeList As ListView
End Class
