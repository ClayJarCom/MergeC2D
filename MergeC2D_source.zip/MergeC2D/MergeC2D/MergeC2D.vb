﻿Option Explicit On
Imports System.Web.Script.Serialization
Imports System.IO

Public Class MergeC2D
    Private jss = New JavaScriptSerializer
    Private jsonMerged = False
    Private toolpathGroupSupport As Boolean = True
    Private Function LoadC2D(FileName As String) As Object
        Dim c2d As String = File.ReadAllText(FileName)
        jss.MaxJsonLength = 1024 * 1024 * 1024

        Dim json = jss.Deserialize(Of Object)(c2d)
        Dim guid = "{" & System.Guid.NewGuid.ToString() & "}"

        Dim i As Integer, Count As Integer
        For Each Key As String In json.keys
            Try
                Count = json(Key).length
            Catch ex As Exception
                Count = 0
            End Try
            For i = 0 To Count - 1
                Try
                    For Each kvp As KeyValuePair(Of String, Object) In json(Key)(i)
                        If kvp.Key = "group_id" Then
                            ReDim Preserve json(Key)(i)(kvp.Key)(json(Key)(i)(kvp.Key).Length)
                            json(Key)(i)(kvp.Key)(json(Key)(i)(kvp.Key).Length - 1) = guid
                        End If
                    Next
                Catch ex As Exception

                End Try
            Next
        Next
        Return json
    End Function

    Private Function Merge(MergeFrom As Object, ByRef MergeInto As Object, Optional GroupName As String = "Group") As Boolean
        Dim i As Integer, Count As Integer, j As Integer
        Dim FromHasTPG = HasGroupedToolpaths(MergeFrom)
        For Each Key As String In MergeFrom.keys
            If Key = "DOCUMENT_VALUES" Then
                Continue For
            End If
            If MergeFrom(Key).Length > 0 Then
                If (Key = "TOOLPATH_OBJECTS") And toolpathGroupSupport Then
                    ' Merging from a file with no toolpath group support to one that does?
                    ' Add the set of toolpath objects as a new group.
                    Dim a = MergeInto("TOOLPATH_GROUP_OBJECTS")
                    ReDim Preserve MergeInto("TOOLPATH_GROUP_OBJECTS")(MergeInto("TOOLPATH_GROUP_OBJECTS").length)
                    MergeInto("TOOLPATH_GROUP_OBJECTS")(MergeInto("TOOLPATH_GROUP_OBJECTS").length - 1) = New Dictionary(Of String, Object) From {{"TOOLPATH_OBJECTS", MergeFrom(Key)}, {"enabled", True}, {"name", GroupName}, {"uuid", "{" & System.Guid.NewGuid.ToString() & "}"}}
                ElseIf (Key = "TOOLPATH_GROUP_OBJECTS") And Not toolpathGroupSupport Then
                    ' Merging from a file with toolpath group support to one that doesn't?
                    ' Add the set of toolpath objects as a new group.
                    Dim tpgo = MergeFrom("TOOLPATH_GROUP_OBJECTS")
                    For i = 0 To tpgo.length - 1
                        For Each kvp As KeyValuePair(Of String, Object) In tpgo(i)
                            If kvp.Key = "TOOLPATH_OBJECTS" Then
                                ReDim Preserve MergeInto("TOOLPATH_OBJECTS")(MergeInto("TOOLPATH_OBJECTS").length - 1 + kvp.Value.length)
                                Count = kvp.Value.length
                                For j = 0 To Count - 1
                                    MergeInto("TOOLPATH_OBJECTS")(MergeInto("TOOLPATH_OBJECTS").length - Count + j) = kvp.Value(j)
                                Next
                            End If
                        Next
                    Next
                Else
                    ReDim Preserve MergeInto(Key)(MergeInto(Key).length - 1 + MergeFrom(Key).length)
                    Count = MergeFrom(Key).length
                    For i = 0 To Count - 1
                        MergeInto(Key)(MergeInto(Key).length - Count + i) = MergeFrom(Key)(i)
                    Next
                End If
            End If
        Next
        Return True
    End Function

    Private Function SaveC2D(FileName As String, json As Object) As Boolean
        Dim c2d As String = jss.Serialize(json)
        File.WriteAllText(FileName, c2d)
        Return True
    End Function

    Private Function SupportsToolpathGroups(json As Object) As Boolean
        Try
            Dim Length = json("TOOLPATH_GROUP_OBJECTS").length
            Return True
        Catch
            Return False
        End Try
    End Function

    Private Function HasGroupedToolpaths(json As Object) As Boolean
        Dim Length As Integer = 0
        Try
            Length = json("TOOLPATH_GROUP_OBJECTS").length
        Catch
        End Try
        If Length > 0 Then
            Return True
        End If
        Return False
    End Function

    Private Sub MergeC2D_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        MergeC2D_Resize(sender, e)
    End Sub

    Private Sub Load_Click(sender As Object, e As EventArgs) Handles LoadFile.Click
        Dim Result As DialogResult = OpenC2D.ShowDialog()
        If Result = DialogResult.OK Then
            Dim json = LoadC2D(OpenC2D.FileName)
            If TypeName(jsonMerged) <> "Boolean" Then
                Merge(json, jsonMerged, System.IO.Path.GetFileNameWithoutExtension(OpenC2D.FileName))
                With MergeList
                    .BeginUpdate()
                    .Items.Add("Merge: " & OpenC2D.FileName)
                    If (toolpathGroupSupport = False) And HasGroupedToolpaths(json) Then
                        Dim it = New ListViewItem("    Toolpaths will be ungrouped.")
                        it.Font = New Font(.Font, FontStyle.Bold)
                        .Items.Add(it)
                    End If
                    .EndUpdate()
                End With
                SaveFile.Enabled = True
            Else
                toolpathGroupSupport = SupportsToolpathGroups(json)
                jsonMerged = json
                With MergeList
                    .Items.Clear()
                    .BeginUpdate()
                    .Items.Add("Main File: " & OpenC2D.FileName)
                    If Not toolpathGroupSupport Then
                        Dim it = New ListViewItem("   Old format -- no toolpath group support.")
                        it.Font = New Font(.Font, FontStyle.Bold)
                        .Items.Add(it)
                    End If
                    .EndUpdate()
                End With
            End If
        End If
    End Sub

    Private Sub Clear_Click(sender As Object, e As EventArgs) Handles Clear.Click
        MergeList.Items.Clear()
        jsonMerged = False
        SaveFile.Enabled = False
    End Sub

    Private Sub SaveFile_Click(sender As Object, e As EventArgs) Handles SaveFile.Click
        Dim Result As DialogResult = SaveAs.ShowDialog
        If Result = DialogResult.OK Then
            SaveC2D(SaveAs.FileName, jsonMerged)
            jsonMerged = False
            With MergeList
                .BeginUpdate()
                .Items.Add("-- Merged C2D File Saved --")
                .Items.Add(SaveAs.FileName)
                .EndUpdate()
            End With
            SaveFile.Enabled = False
        End If
    End Sub

    Private Sub MergeC2D_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        MergeBox.Width = Me.ClientSize.Width - 12
        MergeBox.Height = Me.ClientSize.Height - Clear.Height - 12

        MergeList.Width = MergeBox.Width - 20
        MergeList.Height = MergeBox.Height - 39

        Clear.Top = MergeBox.Height + 6
        SaveFile.Top = MergeBox.Height + 6
        SaveFile.Left = Me.ClientSize.Width - SaveFile.Width - 7
        LoadFile.Top = MergeBox.Height + 6
        LoadFile.Left = SaveFile.Left - LoadFile.Width - 6
    End Sub
End Class
